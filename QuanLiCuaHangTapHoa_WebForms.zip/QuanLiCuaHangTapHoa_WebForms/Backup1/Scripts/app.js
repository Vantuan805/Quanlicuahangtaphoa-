/* ===================================================================
   HỆ THỐNG QUẢN LÝ CỬA HÀNG TẠP HÓA - CLIENT SCRIPTS (WEBFORMS)
   =================================================================== */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Live Clock
    initLiveClock();

    // 2. Sidebar Toggle for Mobile
    initSidebar();

    // 3. F2 Shortcut for POS Cashier
    document.addEventListener('keydown', function (e) {
        if (e.key === 'F2') {
            e.preventDefault();
            window.location.href = 'POS.aspx';
        }
    });

    // 4. Quick POS Button in Topbar
    const btnQuickPos = document.getElementById('topbar-quick-pos');
    if (btnQuickPos) {
        btnQuickPos.addEventListener('click', function () {
            window.location.href = 'POS.aspx';
        });
    }

    // 5. Low stock alert button in Topbar
    const btnLowStock = document.getElementById('topbar-lowstock-btn');
    if (btnLowStock) {
        btnLowStock.addEventListener('click', function () {
            window.location.href = 'Inventory.aspx?status=low';
        });
    }
});

// Live Clock implementation
function initLiveClock() {
    const clockEl = document.getElementById('live-clock');
    if (!clockEl) return;

    function updateTime() {
        const now = new Date();
        const dateStr = now.toLocaleDateString('vi-VN', {
            weekday: 'short',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
        const timeStr = now.toLocaleTimeString('vi-VN', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

        const dateSpan = clockEl.querySelector('.clock-date');
        const timeSpan = clockEl.querySelector('.clock-time');
        if (dateSpan) dateSpan.textContent = dateStr;
        if (timeSpan) timeSpan.textContent = timeStr;
    }

    updateTime();
    setInterval(updateTime, 1000);
}

// Sidebar toggle implementation
function initSidebar() {
    const toggleBtn = document.getElementById('sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('open');
        });
    }
}

// Modal Helpers
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'flex';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        modal.style.display = 'none';
    }
}

// Toast Notifications
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    if (type === 'warning') icon = '⚠️';
    if (type === 'danger' || type === 'error') icon = '❌';

    toast.innerHTML = `
        <span class="toast-icon">${icon}</span>
        <div class="toast-message">${message}</div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('show');
    }, 10);

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentElement) toast.parentElement.removeChild(toast);
        }, 300);
    }, 4000);
}

// Print Receipt Helper
function printReceipt(elemId) {
    const printContent = document.getElementById(elemId);
    if (!printContent) return;
    window.print();
}
